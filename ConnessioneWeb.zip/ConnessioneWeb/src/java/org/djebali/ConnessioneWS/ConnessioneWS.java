/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.djebali.ConnessioneWS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author djebali_ismail
 */
@WebService(serviceName = "ConnessioneWS")
public class ConnessioneWS {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Login")
    public String Login(@WebParam(name = "Username") String Username, @WebParam(name = "Password") String Password) {
        //TODO write your implementation code here:
        Username="";
        Password="";
        return null;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Register")
    public String Register(@WebParam(name = "Name") String Name, @WebParam(name = "Surname") String Surname, @WebParam(name = "Username") String Username, @WebParam(name = "Password") String Password) {
        //TODO write your implementation code here:
        Name="";
        Surname="";
        Username="";
        Password="";
        return null;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Connessione")
    public boolean Connessione(@WebParam(name = "CONN") boolean CONN) {
        //TODO write your implementation code here:
        CONN=false;
        return CONN;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Disconnessione")
    public boolean Disconnessione(@WebParam(name = "DISCONN") boolean DISCONN) {
        //TODO write your implementation code here:
        DISCONN=true;
        return DISCONN;
    }



}
