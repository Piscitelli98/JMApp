/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nb_clientconnessioneweb;

/**
 *
 * @author djebali_ismail
 */
public class NB_ClientConnessioneWeb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //DEVO CONTINUARE DA QUI CON LA CONNESSIONE
    }

    private static boolean connessione(boolean conn) {
        org.djebali.connessionews.ConnessioneWS_Service service = new org.djebali.connessionews.ConnessioneWS_Service();
        org.djebali.connessionews.ConnessioneWS port = service.getConnessioneWSPort();
        return port.connessione(conn);
    }

    private static boolean disconnessione(boolean disconn) {
        org.djebali.connessionews.ConnessioneWS_Service service = new org.djebali.connessionews.ConnessioneWS_Service();
        org.djebali.connessionews.ConnessioneWS port = service.getConnessioneWSPort();
        return port.disconnessione(disconn);
    }

    private static String login(java.lang.String username, java.lang.String password) {
        org.djebali.connessionews.ConnessioneWS_Service service = new org.djebali.connessionews.ConnessioneWS_Service();
        org.djebali.connessionews.ConnessioneWS port = service.getConnessioneWSPort();
        return port.login(username, password);
    }

    private static String register(java.lang.String name, java.lang.String surname, java.lang.String username, java.lang.String password) {
        org.djebali.connessionews.ConnessioneWS_Service service = new org.djebali.connessionews.ConnessioneWS_Service();
        org.djebali.connessionews.ConnessioneWS port = service.getConnessioneWSPort();
        return port.register(name, surname, username, password);
    }
    
}
