/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.corcperego.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author pereg
 */
@WebService(serviceName = "circolariP")
public class circolariP {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "set_nomeCircolare")
    public String set_nomeCircolare(@WebParam(name = "parameter") String parameter) {
        try {
            setNomeCDatabase(parameter);
        } catch (SQLException ex) {
            Logger.getLogger(circolariP.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(circolariP.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    private boolean setNomeCDatabase(String nomeC) throws SQLException, ClassNotFoundException {
        // JDBC driver name and database URL
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost/web_service_test";

        //  Database credentials
        String USER = "root";
        String PASS = "";

        //  Object for connection
        Connection conn = null;
        
        //  Object for SQL query
        Statement stmt = null;

    
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            String sql = "";

            
             System.out.println("Inserting records into the table...");
      
            sql = "INSERT INTO circolari " +
                         "VALUES ('"+nomeC+"')";
            stmt.executeUpdate(sql);
           /* sql = "INSERT INTO Registration " +
                         "VALUES (101, 'Mahnaz', 'Fatma', 25)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO Registration " +
                         "VALUES (102, 'Zaid', 'Khan', 30)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO Registration " +
                         "VALUES(103, 'Sumit', 'Mittal', 28)";
            stmt.executeUpdate(sql);*/
            System.out.println("Inserted records into the table...");
            
            
            /*sql = "SELECT * FROM operazioni";

            if (sql != null) {
                ResultSet rs = stmt.executeQuery(sql);

                // iterate through the java resultset
                while (rs.next()) {
                    //Retrieve by column name
                    int id = rs.getInt("id");
                    String nome = rs.getString("nome");

               
                    // debug: print the results
                    System.out.format("%s, %s\n", id, nome);
                }
            

                rs.close();
            }
 
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        //end try//end try//end try//end try
*/
            //finally block used to close resources
      try{
         if(stmt!=null)
            conn.close();
      }catch(SQLException se){
      }// do nothing
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }//end finally try
    System.out.println("Goodbye!");
        return true;
    }

    /**
     * Web service operation
     */
}
