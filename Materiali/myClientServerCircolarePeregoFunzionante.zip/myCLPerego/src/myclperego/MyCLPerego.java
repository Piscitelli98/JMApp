/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myclperego;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pereg
 */
public class MyCLPerego {

    /**
     * @param args the command line arguments
     */
      private static final String SERVER_HOST = "127.0.0.1";
  private static final int SERVER_PORT = 3333;
  private static final String nomeFile="testSendPDF.pdf";
    
    public static void main(String[] args) {
          try {
              setNomeCircolare(nomeFile);
              sendFile();
          } catch (IOException ex) {
              Logger.getLogger(MyCLPerego.class.getName()).log(Level.SEVERE, null, ex);
          }
    }

    private static String setNomeCircolare(java.lang.String parameter) {
        org.cu.CircolariP_Service service = new org.cu.CircolariP_Service();
        org.cu.CircolariP port = service.getCircolariPPort();
        return port.setNomeCircolare(parameter);
    }
    
     private static void sendFile() throws IOException {
    try {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT)) {
            FileInputStream fis = new FileInputStream(nomeFile);
            OutputStream out = socket.getOutputStream();
            byte[] buf = new byte[1024];
            int read;
            while ((read = fis.read(buf)) != -1) {
                out.write(buf, 0, read);
            }
            fis.close();
            out.close();
        }
            } catch (UnknownHostException ex) {
            System.out.println(ex.getMessage());
            } catch (IOException ex) {
            System.out.println(ex.getMessage());
            }
        }  
    
}
