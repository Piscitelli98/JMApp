/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.djebali.ConnessioneWS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author djebali_ismail
 */
@WebService(serviceName = "ConnessioneWS")
public class ConnessioneWS {
    
    String vetUsarname[] = null, vetPassword[] = null;
    
    int numEl=1;
    Boolean connesso, disconnesso;
    /**
     * Web service operation
     */
    @WebMethod(operationName = "Login")
    public String Login(@WebParam(name = "Usarname") String Username, @WebParam(name = "Password") String Password) {
        //TODO write your implementation code here:
        vetUsarname[0]="ciao"; vetPassword[0]="ciao";
        Boolean sent=false;
        for(int i=0;i<=numEl && sent==false;i++){
            if(Username.equals(vetUsarname[i]) && Password.equals(vetPassword[i]))
            {
                sent=true;
            }           
        }
        if(sent)
        {
            Disconnessione(false);
            Connessione(true);
            return "Utente connesso";
        }
        else
        {
            Connessione(false);
            Disconnessione(true);
            return "Username o password errati. Disconnesso";
        }
    }
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "Register")
    public String Register(@WebParam(name = "Username") String Username, @WebParam(name = "Password") String Password) {
        //TODO write your implementation code here:
        numEl++;
        vetUsarname[numEl]=Username;
        vetPassword[numEl]=Password;
        Disconnessione(false);
        Connessione(true);
        
        return "Utente registrato /n/r Connesso";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Connessione")
    public void Connessione(@WebParam(name = "CONN") boolean CONN) {
        //TODO write your implementation code here:
        connesso=CONN;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Disconnessione")
    public void Disconnessione(@WebParam(name = "DISCONN") boolean DISCONN) {
        //TODO write your implementation code here:
        disconnesso=DISCONN;
    }
    
    public Boolean getConnesso()
    {
        return connesso;
    }
    
    public Boolean getDisconnesso()
    {
        return disconnesso;
    }
}
