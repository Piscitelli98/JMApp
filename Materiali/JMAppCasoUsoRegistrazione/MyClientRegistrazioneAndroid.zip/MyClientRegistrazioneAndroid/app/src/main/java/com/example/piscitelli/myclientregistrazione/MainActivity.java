package com.example.piscitelli.myclientregistrazione;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class MainActivity extends AppCompatActivity {
    EditText nome;
    EditText cognome;
    EditText email;
    EditText psw1;
    EditText psw2;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = (EditText)findViewById(R.id.editTextNome);
        cognome = (EditText)findViewById(R.id.editTextCognome);
        email = (EditText)findViewById(R.id.editTextEmail);
        psw1 = (EditText)findViewById(R.id.editTextPsw1);
        psw2 = (EditText)findViewById(R.id.editTextPsw2);

    }

    public void Registra() {
        if (psw1.getText().equals(psw2.getText().toString())) {
            ConnettiWS connessione = new ConnettiWS();
            connessione.execute(nome.getText().toString(), cognome.getText().toString(), email.getText().toString(), psw1.getText().toString() );
        }
    }



}

public class ConnettiWS extends AsyncTask<String,Void , Void> {
    ProgressDialog pdialog;
    SoapObject request;
    SoapPrimitive registra;

    private static final String SOAP_ACTION = "http://localhost:8080/CasoUsoRegistrazioneTapSchool/RegistrazioneUtenteDB";
    private static final String METHOD_NAME = "RegisterUser";
    private static final String NAMESPACE = "http://RegistrazioneUtenteDB";
    private static final String URL = "http://localhost:8080/CasoUsoRegistrazioneTapSchool/RegistrazioneUtenteDB?wsdl";

    @Override
    protected Void doInBackground(String... params) {

        request = new SoapObject(NAMESPACE, METHOD_NAME);
        request.addProperty("Nome",params[0]);
        request.addProperty("Cognome",params[1]);
        request.addProperty("Email",params[2]);
        request.addProperty("Password",params[3]);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);
        HttpTransportSE httpTransport = new HttpTransportSE(URL);
        try {
            httpTransport.call(SOAP_ACTION, envelope);
            registra = (SoapPrimitive) envelope.getResponse();
        } catch (Exception e) {
            e.getMessage();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pdialog.dismiss();
        //Toast.makeText(getApplicationContext(), celtofah.toString() + " Celsius", Toast.LENGTH_SHORT).show();
        //
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pdialog = new ProgressDialog(MainActivity);
        pdialog.setMessage("Registrando...");
        pdialog.show();
    }
}
