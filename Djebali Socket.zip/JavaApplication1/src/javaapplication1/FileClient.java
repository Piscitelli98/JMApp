/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.*;
import java.net.*;

class Client
{
    public static void main(String[] args) throws Exception
    {
        System.out.println("Sending a Request...");
        try
        {
            Socket s = new Socket("172.16.102.64", 444);
            System.out.println("Connected Successfully");
            
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            PrintStream ps = new PrintStream(s.getOutputStream());
            BufferedReader brs = new BufferedReader(new InputStreamReader(s.getInputStream()));
            while(true)
            {
                System.out.println(("Input the Data..."));
                String st = br.readLine();
                ps.println(st);
                if(st.equals("exit"))
                {
                    System.exit(1);
                }
            System.out.println("Data Returned");
            System.out.println(st);
            }
        }
        catch(UnknownHostException e)
        {
            System.out.println("Smething went wrong with IP " + e);
        }
        catch(IOException e)
        {
            System.out.println("Not found data for the socket " + e);
        }
    }    
}
