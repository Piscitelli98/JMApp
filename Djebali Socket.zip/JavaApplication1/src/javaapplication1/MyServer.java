/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.*;
import java.net.*;

public class MyServer
{
    
    public static void main(String[] args) throws Exception
    {
        try
        {
            ServerSocket ss = new ServerSocket(444);
            System.out.println("Waiting for request...");
            Socket s = ss.accept();
            System.out.println("Request Accepted");
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            while(true)
            {
                String st = br.readLine();
                if(st.equals("exit")==true)
                {
                    System.out.println("Connection lost");
                    System.exit(1);
                }
                System.out.println("Message from Client: " + st); 
            }
        }
        catch(IOException e)
        {
            System.out.println("Not found data fr the socket" + e);
        }
    } 
}