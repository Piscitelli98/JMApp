/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nb_clientwslogin;

/**
 *
 * @author Piscitelli_Federico
 */
public class NB_ClientWSLogin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ris=checkLogin("pippo","ciao");
        
        if(ris.compareTo("ok")==0)
            System.out.println("Password corretta");
        else
              System.out.println("Password errata");
    }

    private static String checkLogin(java.lang.String username, java.lang.String password) {
        org.kikko.loginws.LoginWS_Service service = new org.kikko.loginws.LoginWS_Service();
        org.kikko.loginws.LoginWS port = service.getLoginWSPort();
        return port.checkLogin(username, password);
    }
    
}
