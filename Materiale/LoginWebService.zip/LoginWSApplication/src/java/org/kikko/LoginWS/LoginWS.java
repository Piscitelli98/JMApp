/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.kikko.LoginWS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Piscitelli_Federico
 */
@WebService(serviceName = "LoginWS")
public class LoginWS {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "checkLogin")
    public String checkLogin(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        String ris="";
        
        if(username.compareTo("pippo")==0 && password.compareTo("ciao")==0)
        {
            ris="ok";
        } 
        else {
            ris="no";
        }
        return ris;
    }
}
